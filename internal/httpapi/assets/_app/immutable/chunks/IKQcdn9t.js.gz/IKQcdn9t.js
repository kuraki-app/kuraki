import{R as o}from"./-UyI9lYi.js";import"./B0XwC4Ot.js";function n(r,t){throw new o(r,t.toString())}export{n as r};
